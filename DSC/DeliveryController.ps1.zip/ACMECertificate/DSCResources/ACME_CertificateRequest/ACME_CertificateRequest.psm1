Import-Module ACMEPowerShell

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CommonName,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$ACMEServer,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$EmailAddress,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VaultPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$IISPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$KeyPath,
		
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$PairPath

	)

    process
    {
	    return @{
            CommonName = $CommonName
            ACMEServer = $ACMEServer
            EmailAddress = $EmailAddress
            VaultPath = $VaultPath
            IISPath = $IISPath
		    PairPath = $PairPath
	    }
    }
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CommonName,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$ACMEServer,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$EmailAddress,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VaultPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$IISPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$KeyPath,
		
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$PairPath
	)

    begin
    {    
        $json = @"
        {
          "Provider": {
            "`$type": "ACMESharp.WebServer.IisSitePathProvider, ACMESharp",

            // WebSiteRoot is the required path to the root directory of the target
            // IIS Web site where the content of the challenge response will be saved.
            "WebSiteRoot": "$IISPath"
          }
        }
"@
    }

    process
    {
        $retries = 10
        $delay = 10
   
        $requests = 0

        while($requests -lt $retries)
        {
            try
            {
                # Requests a certificate from the ACME protocol server given 
                # This could fail for a number of reasons, so there is retry logic here

                # Setup
                New-Item $VaultPath -ItemType Directory -ErrorAction SilentlyContinue

                cd $VaultPath

                Initialize-ACMEVault -BaseURI $ACMEServer -Force $true -ErrorAction Stop

                New-ACMERegistration -Contacts "mailto:$EmailAddress" -ErrorAction Stop

                Update-ACMERegistration -AcceptTOS -ErrorAction Stop

                New-ACMEIdentifier -Dns $CommonName -Alias dns1 -Label "NetScaler domain" `
                                   -Memo "NetScaler domain" -ErrorAction Stop

                New-ACMEProviderConfig -WebServerProvider IisSitePath -Alias iisSiteHttpProvider `
                                       -EditWith "powershell.exe" -ErrorAction Stop

                # Challenge

                Get-Item $VaultPath\10-PRVDR\*.json | %{ $json | Set-Content -Path $_.FullName }

                Complete-ACMEChallenge -Ref dns1 -Challenge http-01 -ProviderConfig iisSiteHttpProvider `
                                       -ErrorAction Stop

                Submit-ACMEChallenge -Ref dns1 -Challenge http-01 -ErrorAction Stop

                Write-Verbose "Submitted"

                $tries = 0

                Start-Sleep -Seconds $delay
                
                # Wait for our challenge response to be validated

                while ((Update-ACMEIdentifier -Ref dns1 -ErrorAction Stop).Status -ne "valid")
                {
                    Write-Verbose (Update-ACMEIdentifier -Ref dns1 -ErrorAction Stop).Status

                    $tries = $tries + 1

                    if($tries -gt $retries)
                    {
                        Throw "Could not complete domain verification challenge"
                    }

                    Start-Sleep -Seconds $delay
                }

                # Obtain certificate

                New-ACMECertificate -Identifier dns1 -Alias cert1 -Generate -ErrorAction Stop
    
                Submit-ACMECertificate -Ref cert1 -ErrorAction Stop
    
                $tries = 0

                while ((Update-ACMECertificate -Ref cert1 -ErrorAction Stop).
                       CertificateRequest.StatusCode -ne "OK")
                {
                    Write-Verbose (Update-ACMECertificate -Ref cert1 -ErrorAction Stop).
                                   CertificateRequest

                    $tries = $tries + 1

                    if($tries -gt $retries)
                    {
                        Throw "Failed getting certificate from ACME server"
                    }

                    Start-Sleep -Seconds $delay
                }

                Get-ACMECertificate -Ref cert1 -ExportKeyPEM $KeyPath -ExportCertificatePEM $CertPath `
                                    -CertificatePassword $CertificatePassword.GetNetworkCredential().Password `
                                    -ErrorAction Stop
	
                # Create a combined PEM

	            Get-Content $CertPath | Add-Content $PairPath
	            "`n" | Add-Content $PairPath
	            Get-Content $KeyPath | Add-Content $PairPath
			
			    break
            }
            catch
            {
                $requests = $requests + 1
                Start-Sleep -Seconds $delay
            }

            if($requests -eq $retries)
            {
                throw "Exceeded maximum number of retries obtaining certificate"
            }

        }
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CommonName,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$ACMEServer,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$EmailAddress,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VaultPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$IISPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$KeyPath,
		
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$PairPath
	)

    process
    {
        Test-Path $PairPath
    }
}

Export-ModuleMember -Function *-TargetResource

